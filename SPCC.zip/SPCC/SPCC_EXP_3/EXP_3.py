import pandas as pd
import re
f=open("Sample.asm","r")
Symbol=[]
Opcode=[]
Operand=[]
Instructions=[]
pseudo_Opcode=["start","end","using","drop","dc","ds"]
lc_0=["start","end","using","drop"]
mot={"Mnemonic Opcode":[],"Instruction Length":[],"Instruction Format":[]}
pot={"Pseudo Opcode":[]}
st={"Symbol":[],"Value":[],"Length Byte":[],"Relocation":[]}
lt={"Literals":[],"Value":[],"Length":[],"Relocation":[]}
bt={"Register Availability":["N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N"],"Contents of Base Register":["-","-","-","-","-","-","-","-","-","-","-","-","-","-","-","-"]}
loc={"Instruction":[],"Location Counter":[]}
def m_format(Opr):
    Opr=Opr.split(",")
    if Opr[0].isdigit() and Opr[1].isdigit():
        return "RR"
    else:
        return  "RX"
def literals_length(ltr):
    if "F" in ltr:
        return "04"
    elif "H" in ltr:
        return "02"
    elif "D" in ltr:
        return "08"

def base_table(reg):
    reg=reg.split(",")
    bt["Register Availability"][int(reg[1])]="Y"
    bt["Contents of Base Register"][int(reg[1])]=reg[0]

print("Sample.asm : ")

for x in f:
    x=(re.sub(" +"," ",x.strip()))
    print(x)
    Instructions.append(x)
    x=x.split(" ")
    if len(x)==3:
        Symbol.append(x[0])
        Opcode.append(x[1])
        Operand.append(x[2])
    elif len(x)==1:
        Opcode.append(x[0])
        Symbol.append(" ")
        Operand.append(" ")
    elif x[1].lower() in pseudo_Opcode:
        Symbol.append(x[0])
        Opcode.append(x[1])
        Operand.append(" ")
    else:
        Symbol.append(" ")
        Opcode.append(x[0])
        Operand.append(x[1])
         
for i in range(len(Symbol)):
    if Opcode[i].lower()=="using":
        pot["Pseudo Opcode"].append(Opcode[i])
        base_table(Operand[i])
        continue
    if Symbol[i]!=" ":
        st["Symbol"].append(Symbol[i])
        if Opcode[i].lower()=="start":
            st["Length Byte"].append("01")
        else:
            st["Length Byte"].append(literals_length(Operand[i]))
        st["Relocation"].append("R")

    if Opcode[i]!=" ":
        if Opcode[i].lower() in pseudo_Opcode:
            pot["Pseudo Opcode"].append(Opcode[i])
        else:
            mot["Mnemonic Opcode"].append(Opcode[i])
            mot["Instruction Format"].append(m_format(Operand[i]))
            if mot["Instruction Format"][-1]=="RX":
                mot["Instruction Length"].append("04")
            else:
                mot["Instruction Length"].append("02")
    if Operand[i]!=" ":
        if Opcode[i].lower() in pseudo_Opcode and Opcode[i].lower()!="using":
            lt["Literals"].append(Operand[i])
            lt["Length"].append(literals_length(Operand[i]))
            lt["Relocation"]="R"

i=0
lc=0
for instr in Instructions:
    loc["Instruction"].append(instr)
    loc["Location Counter"].append(lc)
    if Opcode[i].lower() not in lc_0:
        if Opcode[i].lower() in pseudo_Opcode:
            lc=lc+int(lt["Length"][lt["Literals"].index(Operand[i])])
        else:
            lc=lc+int(mot["Instruction Length"][mot["Mnemonic Opcode"].index(Opcode[i])])
    i+=1
for sym in st["Symbol"]:
    st["Value"].append(loc["Location Counter"][Symbol.index(sym)])
for opr in lt["Literals"]:
    lt["Value"].append(loc["Location Counter"][Operand.index(opr)])

print("\n---------------------------Pass1----------------------------\n")
print("Location Counter : ")
print(pd.DataFrame(loc))
print("\nPsudo Opcode Table : ")
print(pd.DataFrame(pot))
print("\nMneumonic Opcode Table : ")
print(pd.DataFrame(mot))
print("\nSymbol Table : ")
print(pd.DataFrame(st))
print("\nLiteral Table : ")
print(pd.DataFrame(lt))
print("\n\n----------------------------Pass2-----------------------------")
print("\nBase Table : ")
print(pd.DataFrame(bt))