 /*Lexical Analyzer
 in Python */
 #include <stdio.h>
 #include <conio.h>
 //Hello Dineshkumar Choudhary
 void main{
     int a=27
     if (a==27){
         printf("Hello,Dinesh...\n")
     }
     else{
        printf("Incorrect\n Roll No.")
     }
     getch();
     }