from email import header
from pydoc import tempfilepager
import re
keywords=["main","auto","getch","break","case","char","const","continue","default","do","double","else","enum","extern","float","for","goto","if","int","long","register","return","short","signed","sizeof","static","struct","switch","typedef","union","unsigned","void","volatile","while"]
symbols=[",","=","+",";","(",")","{","}","%"]
processor_directives=["#include"]
header_file=["<stdio.h>","<conio.h>"]
f=open("Sample.c","r")

keyword_token=[]
symbols_token=[]
processor_directives_token=[]
header_file_token=[]
Numbers_token=[]
Message_token=[]
Identifier_token=[]
for x in f:
    x=x.strip()
    if x.startswith("//"):
        continue
    elif x.startswith("/*"):
        comment_flag=True
        continue
    elif x.endswith("*/") or x.startswith("*/"):
        comment_flag=False
        continue
    elif comment_flag==True:
        continue
    x=(re.sub(" +"," ",x))
    list1=[]
    temp=""
    flag=False
    for i in range(0,len(x)):
        if '"' in x[i] and flag==False:
            temp+=x[i]
            flag=True
        elif '"' in x[i] and flag==True:
            temp+=x[i]
            if r'\n' in temp:
                temp=temp.replace(r'\n',"")
            list1.append(temp)
            temp=""
            flag=False
        elif flag==True:
            temp+=x[i]
        elif x[i] in symbols or x[i]==" ":
            list1.append(temp)
            if temp!=" ":
                list1.append(x[i])
            temp=""
        else:
            temp+=x[i]
    if len(temp)!=0:
        list1.append(temp)
    for char in list1:
        if char.isdigit():
            Numbers_token.append(char)
            print("{}->Numbers".format(char))
        elif '"' in char:
            Message_token.append(char[1:-1])
            print("{}->Message".format(char))
        elif char in keywords:
            keyword_token.append(char)
            print("{}->Keyword".format(char))
        elif char in symbols :
            symbols_token.append(char)
            print("{}->Symbols".format(char))
        elif char in processor_directives:
            processor_directives_token.append(char)
            print("{}->Processor Directive".format(char))
        elif char in header_file:
            header_file_token.append(char)
            print("{}->Header File".format(char))
        elif char!=" " and len(char)!=0:
            Identifier_token.append(char)
            print("{}->Identifier".format(char))

print("Processor_Directive : ",processor_directives_token)
print("Header_File : ",header_file_token)
print("Keywords : ",keyword_token)
print("Identifier : ",Identifier_token)
print("Numbers : ",Numbers_token)
print("Symbols : ",symbols_token)
print("Message : ",Message_token)
n=len(processor_directives_token)+len(header_file_token)+len(keyword_token)+len(Identifier_token)+len(Numbers_token)+len(symbols_token)+len(Message_token)
print("Total Tokens : ",n)