T=int(input())
for j in range(0,T):
    N=int(input())
    l=list(map(int,input().split(" ")))
    v=list(map(int,input().split(" ")))
    index=[i for i in range(0,N)]
    l, v, index = (list(t) for t in zip(*sorted(zip(l, v, index))))
    print(l)
    print(v)
    output=[0]*N
    flag=True
    while flag==True:
        flag=False
        flag1=False
        for i in range (0,N):
            if i==N-1:
                if flag1==False:
                    l[i]=l[i]+v[i]
                break
            elif flag1==True:
                flag=False
                continue
            if i!=N-1:
                if v[i]>0 and v[i+1]<0:
                    flag=True
                    if (l[i]+v[i])>=(l[i+1]+v[i+1]):
                        flag1=True
                        l[i]=l[i]+min(v[i],abs(v[i+1]))
                        l[i+1]=l[i+1]-min(v[i],abs(v[i+1]))
                        if v[i] > abs(v[i+1]):
                            l[i+1]=l[i+1]+v[i]-abs(v[i])
                        elif v[i] < abs(v[i+1]):
                            l[i]=l[i]-(v[i]-abs(v[i]))
                        temp=v[i]
                        v[i]=v[i+1]
                        v[i+1]=temp
                        output[index[i]]+=1
                        output[index[i+1]]+=1
                        print("Output : {}".format(output))
                    else:
                        l[i]=l[i]+v[i]
                else:
                    l[i]=l[i]+v[i]
        l, v, index = (list(t) for t in zip(*sorted(zip(l, v, index))))
        print(l)
        print(v)
    print(output)



