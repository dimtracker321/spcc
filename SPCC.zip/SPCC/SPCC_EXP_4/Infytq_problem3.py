N=int(input())
A=input()
flag=False
count=0
temp=0
i=0
flag1=0
while i!=len(A):
    if flag1==0:
        j=i+1
    if A[i]=="1" or (A[i]=="0" and flag==False) :
        if A[i]=="0":
            flag=True
        temp+=1
        i+=1
        flag1=1
    else:
        count=max(temp,count)
        flag=False
        flag1=0
        temp=0
        i=j
count=max(temp,count)
print(count)
